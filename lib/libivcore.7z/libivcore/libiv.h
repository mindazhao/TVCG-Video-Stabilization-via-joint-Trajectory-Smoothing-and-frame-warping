/*
	================================
	LibIV      2009/10/31
	================================

	Main include file
*/

#pragma  once
#include <LibIVException.h>
#include <Tuple.h>
#include <CppHelpers.h>
#include <Array.h>



#ifndef LIBIV_SAFE_NAMESPACE

	using namespace LibIV;
	using namespace LibIV::CppHelpers;
	using namespace LibIV::Exception;
	using namespace LibIV::Math;
	using namespace LibIV::Memory;
	using namespace LibIV::Memory::Array;

#endif
